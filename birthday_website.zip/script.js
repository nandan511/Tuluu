function showSurprise() {
  document.getElementById("surprise").classList.remove("hidden");

  alert("Happy Birthday My Love ❤️🎂");
}
